
   <!--====== Jquery js ======-->
<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
   
   <!--====== Bootstrap js ======-->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   <script src="./assets/js/bootstrap.min.js"></script>
   <!-- ======= Sweet Alert ========= -->
   <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <!--====== Main js ======-->
   <script src="./assets/js/owl.carousel.min.js"></script>
   <script src="./assets/js/wow.min.js"></script>
   <script src="./assets/js/carousel.js"></script>
   <script src="./assets/js/main.js"></script>
   <script src="./assets/js/query.js"></script>
   
   <script src="./assets/js/blogs.js"></script>
</body>

</html>

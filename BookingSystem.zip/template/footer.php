
   <!--====== Jquery js ======-->
   <script src="./assets/js/jquery-1.12.4.min.js"></script>
   
   <!--====== Bootstrap js ======-->
   <script src="./assets/js/bootstrap.bundle.min.js"></script>
   <script src="./assets/js/bootstrap.min.js"></script>
   <!-- ======= Sweet Alert ========= -->
   <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <!--====== Main js ======-->
   <script src="./assets/js/owl.carousel.min.js"></script>
   <script src="./assets/js/wow.min.js"></script>
   <script src="./assets/js/carousel.js"></script>
   <script src="./assets/js/main.js"></script>
   <script src="./assets/js/query.js"></script>
   
   <script src="./assets/js/blogs.js"></script>
</body>

</html>

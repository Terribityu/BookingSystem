<?php
$servername = "localhost";
		$username = "root";
		$password = "";
		$database = "travelbooking";
		$connection = mysqli_connect($servername , $username , $password, $database);
?>
</div>

<script src="./assets/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="./assets/js/script.js"></script>
<script type="text/javascript" src="./assets/js/paging.js"></script> 

</body>
</html>